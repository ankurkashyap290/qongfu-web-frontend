// import { AppState } from "../redux/reducers";
import { AppState } from "../redux/reducers";

export const getAppState = (state: AppState): AppState => state;

// Groups hits by category, limits each category to 4 hits, and converts to product list
